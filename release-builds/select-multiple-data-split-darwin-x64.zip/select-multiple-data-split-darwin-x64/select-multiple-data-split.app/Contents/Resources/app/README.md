## Overview
This is a desktop application developed using electron framework.

### Documentation will be posted soon

